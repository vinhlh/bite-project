//Copyright 2010 Google Inc. All Rights Reserved.

/**
 * @fileoverview This file contains the console manager.
 *
 * @author phu@google.com (Po Hu)
 */


goog.provide('rpf.SaveDialog');



/**
 * A class for handling console's save function.
 * @constructor
 * @export
 */
rpf.SaveDialog = function() {};

